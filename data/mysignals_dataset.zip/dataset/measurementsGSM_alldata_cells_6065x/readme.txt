This file contains all GSM measurements from the 6056x BTS (Base Transceiver Station or simply BS or cell Tower), deployment (i.e. all cells with prefix 6056x). This dataset has been collected by approx. 10 different devices, however, the majority of the measurements come from the 5 devices (described in the directory _StaticAndPrederminedUsersLocation_cells_6056x). The overall data campaign lasted approx. eight months, from Sep. '12 until June '13.

Please note the time interval (dt_i) between the measurement's five consecutive RSSI samples for each record of this dataset. The iPhone's baseband usually needs one second to return a read of RSSI. However, in some rare cases there is a significant delay and we should record this delay (dt_i).

A short description of each measurement's field follows:

1. timestamp: It contains the exact date and the time moment of the measurement.
2. iPhoneUID: the unique iPhone Device pseudoID; a random UUID is generated per device using an MD5 hash of the phone's mac address. No personal identifiable information is being used.
3. dt1: rrsi1 was recorded at the time moment timestamp+dt1 . Each measurement contains a burst of 5 consecutive RSS measurements from the iPhone's baseband. System records 5 consecutive RSSIs for many reasons. For example, we can see if the RSS is constant during a few seconds; this will reveal many properties of the wireless channel at the corresponding time moment.
4.dt2: timestamp+dt1+dt2 was the moment when the rssi2 was recorded.
5. and so ...
6. ...
7. ...
8. rssi_ios: RSSI value provided by the iOS private API. rssi_iOS is presented on the iPhone's screen if you press *3001#12345#*. However, iOS software averages rssi1 ... rssi5 during a time interval which is determined internally by the iPhone. Individually, rssi1 ... rssi5 are more accurate since they are provided by the baseband itself through AT commands and they correspond to instantaneous measurements approximately per second (usually dt_i ~=1 sec).
9. rssi1: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1.
10. rssi2: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt2.
11. rssi3: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt3+dt3.
12. rssi4: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt2+dt3+dt4.
13. rssi5: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt2+dt3+dt4+dt5.
14. measurementLat: latitude provided by the iPhone's aGPS at the moment timestamp.
15. measurementLon: longitude provided by the iPhone's aGPS at the moment timestamp.
16. finLat: latitude provided by the iPhone's aGPS at the moment timestamp+dt1+dt2+dt3+dt4+dt5
17. finLon: longitude provided by the iPhone's aGPS at the moment timestamp+dt1+dt2+dt3+dt4+dt5. Thus, we can determine if the user was moving during the time interval (timestamp-timestamp+timestamp+dt1+dt2+dt3+dt4+dt5) when the mobile was recording the five consecutive RSSIs.
18.  accur: horizontal accuracy provided by the iPhone's aGPS. Experimentally, we determined that the accuracy provided by the mobile phone was very pessimistic.
19. isMoving: 0 if there is no difference between 13,14 and 15,16. otherwise 1.
20. cellID: the identifier of the cell
21. lac: location area code.
22. mnc: mobile network code, i.e. a specific network provider. For instance, mnc=1 ->Cosmote.
23. arfcn: Absolute radio-frequency channel number.
24. freq_dlink: downlink frequency carrier (calculated by ARFCN).
25. freq_uplin: uplink frequency carrier (calculated by ARFCN).
